//Author: Ryan Green
//Lab Partner: Tyler Wilson
package project2;

public class MyNode<AnyType> {
   public AnyType data;
   public MyNode<AnyType> next;
}