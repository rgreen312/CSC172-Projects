//Author: Ryan Green
//Lab Partner: Tyler Wilson
package project2;

public class MyDoubleNode<AnyType> {
   public AnyType data;
   public MyDoubleNode<AnyType> next;
   public MyDoubleNode<AnyType> prev;
}